======================
= c3d_import.py v0.6 =
======================
(C) 2005 Jean-Baptiste PERIN - released under GPL - http://www.gnu.org/copyleft/gpl.html

c3d_importer is a script that loads Graphics Lab Motion Capture file into Blender

ARCHIVE CONTENT:
================

./c3d_import.py         the C3D importer
./ReadMe.txt               this file
./LICENCE.txt              the licence of this script (GPL)


HOW TO USE THIS SCRIPT ?
========================

- Open a Text Editor Window
- In Text Editor Window, open the c3d_import.py script 
- Run the script (Alt-P)
- A file selector is displayed 
- Choose the C3D file to open
- Click the Import C3D button

HOW tO INSTALL THIS SCRIPT ?
============================

Copy c3d_import.py file into the ".blender/scripts" directory of your Blender installation.
In a Script window, go to the "Script" menu entry and perform an "Update Script"
Now, still in a Script window, go to Menu "Script->Import". 
You should see a "Motion Capture  (.c3d)..." entry.


WHERE CAN I FIND C3D FILE :
===========================

this script was tested by using files from the huge database at
http://mocap.cs.cmu.edu/

some attempt were made to make it work with files from :
http://www.c3d.org/download_c3d.htm
but result is weird .. investigating ....

ANYTHING ELSE ?
===============

c3d_importer is released under GPL 
read the LICENCE file or visit:
http://www.gnu.org/copyleft/gpl.html

Futur releases will be made available on:
http://perso.wanadoo.fr/jb.perin/

Bug report, evolution requirements, remarks and comments can be posted here:
http://www.zoo-logique.org/3D.Blender/newsportal/post.php?newsgroups=3D.Blender&type=new
Put [C3D_importer] at the beginning of the "Sujet:" field
